PHANTOM NODE PHM-D
===================

The captured authentication token is in access_token.txt.

OBJECTIVE
---------
Investigate the JWT locally using Termux and recover the final flag.

Suggested workflow:
1. Inspect the JWT header.
2. Inspect the JWT payload.
3. Identify the signing algorithm.
4. Inspect the supplied service configuration.
5. Determine the weakness in the legacy validation setup.
6. Recover the challenge flag.

Useful Termux commands:
  cat access_token.txt
  cut -d '.' -f1 access_token.txt | base64 -d
  cut -d '.' -f2 access_token.txt | base64 -d
  cat service_config.txt

The evidence package contains everything required. Do not attack the challenge server.
